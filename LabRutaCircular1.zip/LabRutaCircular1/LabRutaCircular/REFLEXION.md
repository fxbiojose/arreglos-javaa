# Reflexión - Laboratorio RutaSabana

**1.** En la Parte 1 no hace falta preguntar `if (actual.siguiente == null)` porque en una lista circular ningún enlace es null: el siguiente del último nodo es el primero, así que `actual = actual.siguiente` siempre funciona, incluso al llegar al final. Lo mismo pasa con `anterior` desde la primera parada. Si recorriera esta lista con `while (aux != null)`, el ciclo nunca terminaría, porque nunca se encuentra un null y el recorrido daría vueltas para siempre. Por eso se usa `do { ... } while (aux != primero)`, que se detiene cuando se completa una vuelta. Se usa do-while y no while porque con un while la condición `aux != primero` sería falsa desde el inicio (aux empieza en primero) y no se visitaría nada.

**2.** Si olvido actualizar `primero` al eliminar el primer nodo, `primero` queda apuntando a un nodo que ya salió del círculo. Un caso concreto: la ruta es A, B, C y elimino A. Después del puenteo, C.siguiente es B y B.anterior es C, pero `primero` sigue siendo A. Al llamar `tiempoTotal()` el do-while empieza en A, pasa a B, luego a C, luego otra vez a B, y nunca vuelve a A, así que queda en un ciclo infinito. Además, `agregar` usaría `primero.anterior` como último nodo, que sería un nodo ya eliminado, y la nueva parada quedaría mal enlazada.

**3.** Complejidades (n es el tamaño de la ruta; en `saltar`, k es el valor del salto):

| Operación | Manual (mi lista) | Librería (`LinkedList`) |
|---|---|---|
| `agregar` | O(1), porque el último nodo es `primero.anterior` | O(1), `addLast` |
| `siguiente` / `anterior` | O(1), solo se mueve una referencia | O(1), `removeFirst` + `addLast` (o al revés) |
| `saltar(n)` | O(min(k mod n, n)), como máximo O(n) | O(n), `Collections.rotate` recorre la lista |
| `eliminarActual` | O(1), solo se reasignan dos enlaces | O(1), `removeFirst` |

En `saltar` la lista manual es mejor o igual: con k pequeño solo da k pasos, mientras que `rotate` siempre toca los elementos de la lista aunque el salto sea de una sola parada.

**4.** La ventaja de usar la librería es que hay mucho menos código y menos riesgo de error: `eliminarActual` pasó de unas quince líneas con cuatro enlaces a un `removeFirst`, y ya no hay que cuidar punteros. Además se aprovechan herramientas ya probadas como `Collections.rotate`, `shuffle` o el `ListIterator` (con el que se resolvió `irA`). Lo que se pierde es el control sobre la estructura: la circularidad es solo lógica, el último nodo interno sigue apuntando a null. No existe una referencia independiente a la parada actual, así que "actual" significa "el primero de la cola" y cada `siguiente` modifica realmente el orden interno de la lista. Tampoco se puede recorrer una vuelta empezando donde se quiera sin rotar antes, y `saltar` siempre cuesta O(n).

**5.** Para la parada prioritaria usaría un `PriorityQueue<Parada>`, porque siempre entrega primero la de mayor prioridad sin tener que reordenar toda la ruta (habría que agregarle un campo de prioridad a `Parada` o pasarle un `Comparator`). Para las paradas pendientes usaría una `Queue`, por ejemplo `ArrayDeque`, porque se atienden en el orden en que llegan (FIFO), con inserción y extracción en O(1). La ruta circular seguiría siendo la lista principal y esas dos estructuras serían complementarias.
