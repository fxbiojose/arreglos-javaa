package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

/**
 * PARTE 1 - RutaCircular circular SIN librerías (lista doblemente enlazada circular).
 *
 *            ┌────────────────────────────────────────────┐
 *            ▼                                            │
 *   primero → [A] ⇄ [B] ⇄ [C] ⇄ [D] ⇄ ... ⇄ [Z] ──────────┘
 *              ▲
 *            actual  (la parada que es la parada actual)
 *
 * Dos referencias:
 *   primero: la primera parada agregada. Como la lista es circular,
 *            el ÚLTIMO nodo siempre es  primero.anterior  (¡inserción al final en O(1)!)
 *   actual : la parada que está en servicio ahora
 *
 * Estudiante: busque los comentarios  "TODO"  y complete el código.
 * Después de cada hito ejecute:  mvn test -Dtest=RutaCircularManualTest
 */
public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    // ══════════════════════ HITO 1: agregar (≈ 8 min) ══════════════════════
    @Override
    public void agregar(Parada c) {
        Nodo nuevo = new Nodo(c);

        if (primero == null) {
            // Lista vacía: el nodo se apunta a sí mismo en ambos sentidos (YA RESUELTO)
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
            primero = nuevo;
            actual = nuevo;
        } else {
            Nodo ultimo = primero.anterior;   // el último está "detrás" del primero

            // El nuevo se inserta entre 'ultimo' y 'primero'
            nuevo.anterior = ultimo;
            nuevo.siguiente = primero;
            ultimo.siguiente = nuevo;
            primero.anterior = nuevo;
        }
        tamanio++;
    }

    @Override
    public Parada actual() {
        return actual == null ? null : actual.dato;   // YA RESUELTO
    }

    // ══════════════════ HITO 2: siguiente / anterior (≈ 6 min) ═════════════
    @Override
    public Parada siguiente() {
        if (actual == null) return null;
        actual = actual.siguiente;   // circular: no hace falta preguntar si era el último
        return actual.dato;
    }

    @Override
    public Parada anterior() {
        if (actual == null) return null;
        actual = actual.anterior;    // circular: desde la primera se llega a la última
        return actual.dato;
    }

    // ═════════════════ HITO 3: adelantar / retroceder N (≈ 6 min) ══════════
    @Override
    public Parada saltar(int n) {
        if (actual == null) return null;

        // Las vueltas completas no cambian la posición; el signo se conserva
        n = n % tamanio;

        for (int i = 0; i < n; i++) {
            actual = actual.siguiente;
        }
        for (int i = 0; i > n; i--) {
            actual = actual.anterior;
        }
        return actual.dato;
    }

    // ═══════════════ HITO 4: eliminar la que es la parada actual (≈ 10 min) ══════════════
    @Override
    public Parada eliminarActual() {
        if (actual == null) return null;               // YA RESUELTO: vacía

        if (tamanio == 1) {                            // YA RESUELTO: era la única
            primero = null;
            actual = null;
            tamanio = 0;
            return null;
        }

        // Caso general (hay al menos 2 paradas).
        Nodo previo = actual.anterior;                 // YA RESUELTO
        Nodo proximo = actual.siguiente;

        // Se "puentea" el nodo actual para sacarlo del círculo
        previo.siguiente = proximo;
        proximo.anterior = previo;

        // Si se eliminó 'primero', la referencia debe pasar al nodo que sigue
        if (actual == primero) {
            primero = proximo;
        }

        actual = proximo;
        tamanio--;
        return actual.dato;
    }

    @Override
    public int tamanio() {
        return tamanio;                                // YA RESUELTO
    }

    // ═════════ HITO 5: recorrer una vuelta con do-while (≈ 5 min) ══════════
    @Override
    public int tiempoTotal() {
        if (primero == null) return 0;

        int total = 0;
        Nodo aux = primero;
        do {
            total += aux.dato.minutos();
            aux = aux.siguiente;
        } while (aux != primero);
        return total;
    }

    @Override
    public List<String> nombresDesdeActual() {
        // YA RESUELTO: observe el do-while, es el mismo patrón del Hito 5.
        List<String> nombres = new ArrayList<>();
        if (actual == null) return nombres;
        Nodo aux = actual;
        do {
            nombres.add(aux.dato.nombre());
            aux = aux.siguiente;
        } while (aux != actual);
        return nombres;
    }
}
